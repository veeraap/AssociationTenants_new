namespace ScratchCode.Models;

public enum PageTemplateType
{
    Empty,
    Team,
    EventDetail,
    EventList,
    AboutUs,
    Text,
    Sponsors,
    Blog,
    EventCalendar
}